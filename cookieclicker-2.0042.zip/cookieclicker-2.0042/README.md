cookieclicker
=============

<img src="img/perfectCookie.png">

The original game can be found at http://orteil.dashnet.org/cookieclicker/

This copy for, errrr, like, educational purpose.

Download a copy of this if you want to "educate" yourself offline, or go to http://ozh.github.io/cookieclicker/ if you cannot "educate" yourself on the original URL.
